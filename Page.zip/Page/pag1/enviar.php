<?php
$name = $_POST['name'];
$mail = $_POST['email'];
$date = $_POST['date'];
$message = $_POST['message'];

$header = 'From: ' . $mail . " \r\n";
$header .= "X-Mailer: PHP/" . phpversion() . " \r\n";
$header .= "Mime-Version: 1.0 \r\n";
$header .= "Content-Type: text/plain";

$message = "Mensaje enviado por: " . $name . " \r\n";
$message .= "E-mail: " . $mail . " \r\n";
$message .= "Fecha: " . $date . " \r\n";
$message .= "Mensaje: " . $_POST['message'] . " \r\n";
$message .= "Enviado el: " . date('d/m/Y', time());

$para = 'patricioalcivar98@outlook.es';
$asunto = 'AUTO';

mail($para, $asunto, utf8_decode($message), $header);

header("Location:other.html");
?>
-->
